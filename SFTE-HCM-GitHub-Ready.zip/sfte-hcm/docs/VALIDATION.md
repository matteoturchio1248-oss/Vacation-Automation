# Export validation

Checked October 2, 2026 on Linux with Node 24.19.0.

- Lockfile installation: 538 packages installed with npm ci using the existing offline npm cache.
- TypeScript: passed with no emitted files.
- ESLint: no errors; two unused-disable warnings in generated Worker type definitions.
- Production build: passed; Worker default.fetch and packaged binding manifest validated.
- Existing tests: three passed, zero failed (rendered HTML, isolated runtime permissions/workflows/notifications, vacation period overlap).
- Local bootstrap: 44 SQL commands succeeded against a new local D1 database; zero employee records afterward.
- Export integrity: app/lib/db/drizzle/public files and dependency lockfile match the source snapshot.
- Workflow YAML parsed; selected credential-pattern and private-runtime-file checks passed.

GitHub Actions has not run on GitHub yet. No company-server port, production
migration, independent security audit, browser review or capacity benchmark was
performed for this packaging change. The live Site and jobs were not changed.
No live data or credentials were exported.
