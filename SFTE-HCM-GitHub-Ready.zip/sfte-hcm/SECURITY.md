# Security and private data

Keep this internal HCM repository private. Do not commit employee data, database
exports, sessions, passwords, API keys or Gmail relay secrets. Ignore rules and
the limited source check do not replace staged-file review or a full secret scan.

Report suspected vulnerabilities privately to the repository owner and company
IT. Do not post real employee records or credentials in issues, pull requests,
Actions output or screenshots. No public disclosure email is configured here.

## Current hosting assumptions

The live Site has an owner-private platform gate. That protection does not
accompany a clone or company-server deployment.

`/api/jobs/payroll-digest` relies on that gate and has no application-level
authorization. Add job authentication before exposing it on a new host; do not
reuse the original Site credential.

The first registration on an empty database becomes master administrator.
Provision it behind restricted access before exposing a new installation.
Revalidate role/team restrictions, self-approval protections, session handling
and transaction guarantees after porting the runtime/database.

General reminders may run on page loads; a scheduled hook is not proof of an
active scheduler. Configure credentials and transfer HR data separately. Saved
Gmail relay secrets currently live in database settings; review secret-manager
storage for the target environment.

See `docs/DEVELOPER-HANDOFF.md` for migration details. No independent security
audit or load benchmark is included.
