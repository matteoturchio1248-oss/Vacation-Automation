import { payrollDigestStatus, runPayrollDigest } from "../../../../lib/payroll-reminders";

export const dynamic = "force-dynamic";
// Shared job endpoint: authorization is the confirmed owner-private Sites
// dispatch boundary. It must gain its own authorization before public sharing.
export async function GET() {
  return Response.json(await payrollDigestStatus(), { headers: { "Cache-Control": "private, no-store" } });
}
export async function POST(request: Request) {
  try {
    return Response.json({ ok: true, ...await runPayrollDigest(new URL(request.url).origin) });
  } catch {
    return Response.json({ error: "Payroll digest could not be queued. The next scheduled run can retry." }, { status: 500 });
  }
}
